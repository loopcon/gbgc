@extends('layouts.header')
@section('content')
<div class="thank-youbox">
    <div class="thank-youtext">
        <h2>THANK YOU</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel reprehenderit possimus debitis voluptates.</p>
        <a href="{{route('index')}}" class="thank-go-backbtn"> GO BACK </a>
    </div>
</div>
@endsection