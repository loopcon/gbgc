<div class="col-12 col-md-4 col-lg-3 mb-3">
    <div class="profile-navigation">
        <ul>
            <li><a href="{{route('frontdashboard')}}">Dashboard</a></li>
            <li><a href="{{route('frontreport')}}">Reports</a></li>
            <li><a href="#">Export/Download</a></li>
            <li><a href="{{route('myaccount')}}">My Profile</a></li>
            <li><a href="{{route('customer-logout')}}">Log out</a></li>
        </ul>
    </div>
</div>