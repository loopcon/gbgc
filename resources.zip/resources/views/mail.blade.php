<h1>Hi, {{ $email }}</h1>
<p>GBGC Customer</p>